1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0w2x~-3f4_5s8.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0w2x~-3f4_5s8.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"qwpwUQpJOr5P_wI9AiEMo"}
