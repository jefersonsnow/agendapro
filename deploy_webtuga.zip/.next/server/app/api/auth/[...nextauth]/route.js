var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...nextauth]/route.js")
R.c("server/chunks/[externals]__0_636~4._.js")
R.c("server/chunks/[root-of-the-server]__0jgf-4h._.js")
R.c("server/chunks/node_modules_next_0wy3i-w._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_[___nextauth]_route_actions_04_0y9h.js")
R.m(59061)
module.exports=R.m(59061).exports
