var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/webhooks/kiwify/route.js")
R.c("server/chunks/[root-of-the-server]__05o9ml0._.js")
R.c("server/chunks/[root-of-the-server]__0jgf-4h._.js")
R.c("server/chunks/_next-internal_server_app_api_webhooks_kiwify_route_actions_10~3gc9.js")
R.m(22390)
module.exports=R.m(22390).exports
