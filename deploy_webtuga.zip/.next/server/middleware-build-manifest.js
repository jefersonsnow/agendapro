globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/qwpwUQpJOr5P_wI9AiEMo/_buildManifest.js",
    "static/qwpwUQpJOr5P_wI9AiEMo/_ssgManifest.js",
    "static/qwpwUQpJOr5P_wI9AiEMo/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0t1et0tty8o9s.js",
    "static/chunks/0b.0z4y~q4bv2.js",
    "static/chunks/0bvpl~88n-ttb.js",
    "static/chunks/07dby7~l4ufq..js",
    "static/chunks/0zrob_~.pbt8g.js",
    "static/chunks/01eaypui5.ex0.js",
    "static/chunks/turbopack-0m_drk_coj.i2.js"
  ]
};
