module.exports=[88527,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_webhooks_kiwify_route_actions_10~3gc9.js.map