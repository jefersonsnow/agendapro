module.exports=[30039,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_auth_sign-up-success_page_actions_0ddqt-q.js.map