module.exports=[76580,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_termos_page_actions_0orpjc2.js.map