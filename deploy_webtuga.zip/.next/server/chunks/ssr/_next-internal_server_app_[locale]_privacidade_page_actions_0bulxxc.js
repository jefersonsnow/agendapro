module.exports=[21959,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_privacidade_page_actions_0bulxxc.js.map