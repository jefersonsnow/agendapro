module.exports=[95521,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_ajuda_gestao-agenda_page_actions_0fwyefk.js.map