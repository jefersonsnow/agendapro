module.exports=[11979,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_auth_error_page_actions_10g_136.js.map