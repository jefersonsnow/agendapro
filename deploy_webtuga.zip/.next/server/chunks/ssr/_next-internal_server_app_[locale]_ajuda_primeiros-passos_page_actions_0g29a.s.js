module.exports=[34247,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_ajuda_primeiros-passos_page_actions_0g29a.s.js.map