module.exports=[64324,(a,b,c)=>{}];

//# sourceMappingURL=0zjb_server_app_%5Blocale%5D_ajuda_faturacao-comissoes_page_actions_09uhfg4.js.map